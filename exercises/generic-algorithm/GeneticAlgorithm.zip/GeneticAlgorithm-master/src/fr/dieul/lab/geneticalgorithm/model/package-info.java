package fr.dieul.lab.geneticalgorithm.model;

/* This package should contain all the model/business classes such as Population, Individual*/