package fr.dieul.lab.geneticalgorithm.util;

/* This package should contain all utility classes, that bring some features to the application but no business value*/